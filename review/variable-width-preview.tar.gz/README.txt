Fazhere Studio — Variable Width

Extract the archive. With Node.js 22 installed, open a terminal in the extracted directory and run:
    node serve.mjs
Open http://127.0.0.1:4173/ in your browser. Press Ctrl+C to stop.
To choose another port, pass its number after serve.mjs.

The dist directory contains the production website. The local tour and project exhibits work without internet.
Links to the live store, project source, and WhatsApp open their usual destinations.
